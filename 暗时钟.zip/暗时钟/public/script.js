let lastSecond = -1;
let clockCounter = 0;
let activeClock = 0; // 当前活跃的时钟ID
let frozenClocks = new Set(); // 存储被定格的时钟ID
let clockStartTimes = new Map(); // 存储每个时钟的开始时间

// 数据持久化相关函数
function saveToLocalStorage() {
    try {
        const data = {
            clockCounter,
            activeClock,
            frozenClocks: Array.from(frozenClocks),
            clockStartTimes: Array.from(clockStartTimes.entries()),
            clocksData: []
        };
        
        // 保存每个时钟的数据
        for (let i = 0; i <= clockCounter; i++) {
            const clockContainer = document.querySelector(`[data-clock-id="${i}"]`);
            if (clockContainer) {
                const memoryTextarea = document.getElementById(`memory-${i}`);
                const digitalTime = document.getElementById(`digitalTime-${i}`);
                const date = document.getElementById(`date-${i}`);
                const memoryTitle = document.getElementById(`memoryTitle-${i}`);
                
                // 获取指针角度
                const hourHand = document.getElementById(`hourHand-${i}`);
                const minuteHand = document.getElementById(`minuteHand-${i}`);
                const secondHand = document.getElementById(`secondHand-${i}`);
                
                const clockData = {
                    id: i,
                    memoryText: memoryTextarea ? memoryTextarea.value : '',
                    digitalTime: digitalTime ? digitalTime.textContent : '',
                    date: date ? date.textContent : '',
                    memoryTitle: memoryTitle ? memoryTitle.textContent : '这段时光里...',
                    isFrozen: frozenClocks.has(i),
                    hourHandAngle: hourHand ? hourHand.style.transform : '',
                    minuteHandAngle: minuteHand ? minuteHand.style.transform : '',
                    secondHandAngle: secondHand ? secondHand.style.transform : ''
                };
                
                data.clocksData.push(clockData);
            }
        }
        
        localStorage.setItem('darkClockData', JSON.stringify(data));
    } catch (error) {
        console.error('保存数据到本地存储失败:', error);
    }
}

function loadFromLocalStorage() {
    try {
        const savedData = localStorage.getItem('darkClockData');
        if (!savedData) return false;
        
        const data = JSON.parse(savedData);
        
        // 恢复基本数据
        clockCounter = data.clockCounter || 0;
        activeClock = data.activeClock || 0;
        frozenClocks = new Set(data.frozenClocks || []);
        
        // 恢复时钟开始时间，确保转换为Date对象
        clockStartTimes = new Map();
        if (data.clockStartTimes) {
            data.clockStartTimes.forEach(([key, value]) => {
                clockStartTimes.set(key, new Date(value));
            });
        }
        
        // 恢复时钟数据
        const clocksContainer = document.getElementById('clocksContainer');
        if (data.clocksData && data.clocksData.length > 0) {
            // 清空现有的时钟容器（除了第一个）
            const existingClocks = clocksContainer.querySelectorAll('.clock-container');
            if (existingClocks.length > 1) {
                for (let i = 1; i < existingClocks.length; i++) {
                    existingClocks[i].remove();
                }
            }
            
            // 恢复所有时钟
            data.clocksData.forEach(clockData => {
                if (clockData.id === 0) {
                    // 更新第一个时钟
                    updateClockFromData(clockData);
                } else {
                    // 创建新的时钟
                    const newClockDiv = document.createElement('div');
                    newClockDiv.innerHTML = createClockHTML(clockData.id);
                    clocksContainer.appendChild(newClockDiv.firstElementChild);
                    
                    // 等待DOM更新后设置数据
                    setTimeout(() => {
                        updateClockFromData(clockData);
                    }, 50);
                }
            });
        }
        
        return true;
    } catch (error) {
        console.error('从本地存储加载数据失败:', error);
        return false;
    }
}

function updateClockFromData(clockData) {
    const memoryTextarea = document.getElementById(`memory-${clockData.id}`);
    const digitalTime = document.getElementById(`digitalTime-${clockData.id}`);
    const date = document.getElementById(`date-${clockData.id}`);
    const memoryTitle = document.getElementById(`memoryTitle-${clockData.id}`);
    const hourHand = document.getElementById(`hourHand-${clockData.id}`);
    const minuteHand = document.getElementById(`minuteHand-${clockData.id}`);
    const secondHand = document.getElementById(`secondHand-${clockData.id}`);
    const clockContainer = document.querySelector(`[data-clock-id="${clockData.id}"]`);
    
    if (memoryTextarea) memoryTextarea.value = clockData.memoryText;
    if (digitalTime) digitalTime.textContent = clockData.digitalTime;
    if (date) date.textContent = clockData.date;
    if (memoryTitle) memoryTitle.textContent = clockData.memoryTitle;
    if (hourHand) hourHand.style.transform = clockData.hourHandAngle;
    if (minuteHand) minuteHand.style.transform = clockData.minuteHandAngle;
    if (secondHand) secondHand.style.transform = clockData.secondHandAngle;
    
    // 如果是定格的时钟，添加frozen类
    if (clockData.isFrozen && clockContainer) {
        clockContainer.classList.add('frozen');
    }
}

function setupAutoSave() {
    // 监听所有记录文本框的变化
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('memory-textarea')) {
            // 延迟保存，避免频繁保存
            clearTimeout(window.autoSaveTimeout);
            window.autoSaveTimeout = setTimeout(saveToLocalStorage, 1000);
        }
    });
    
    // 页面关闭前保存
    window.addEventListener('beforeunload', saveToLocalStorage);
    
    // 定期保存（每30秒）
    setInterval(saveToLocalStorage, 30000);
}

// 数据管理函数
function getDataSize() {
    try {
        const data = localStorage.getItem('darkClockData');
        if (data) {
            const sizeInBytes = new Blob([data]).size;
            const sizeInKB = (sizeInBytes / 1024).toFixed(2);
            return {
                bytes: sizeInBytes,
                kb: sizeInKB,
                recordCount: JSON.parse(data).clocksData ? JSON.parse(data).clocksData.length : 0
            };
        }
        return { bytes: 0, kb: '0.00', recordCount: 0 };
    } catch (error) {
        console.error('获取数据大小失败:', error);
        return { bytes: 0, kb: '0.00', recordCount: 0 };
    }
}

function clearAllData() {
    if (confirm('确定要清除所有保存的数据吗？此操作不可撤销！')) {
        localStorage.removeItem('darkClockData');
        location.reload(); // 重新加载页面
    }
}

function showDataInfo() {
    const dataSize = getDataSize();
    console.log(`
=== 暗时钟数据信息 ===
存储记录数量: ${dataSize.recordCount}
数据大小: ${dataSize.kb} KB (${dataSize.bytes} 字节)
浏览器存储限制: 约 5-10 MB
剩余空间: 充足 (约 ${(5000 - parseFloat(dataSize.kb)).toFixed(2)} KB)
===================
    `);
    
    // 也在页面上显示（可选）
    const info = `数据大小: ${dataSize.kb} KB | 记录数: ${dataSize.recordCount}`;
    console.log('当前数据状态:', info);
}

// 数据修复函数
function repairClockData() {
    console.log('开始修复时钟数据...');
    
    // 确保所有活跃时钟都有开始时间
    const now = new Date();
    for (let i = 0; i <= clockCounter; i++) {
        const clockContainer = document.querySelector(`[data-clock-id="${i}"]`);
        if (clockContainer && !frozenClocks.has(i) && !clockStartTimes.has(i)) {
            clockStartTimes.set(i, now);
            console.log(`为时钟 ${i} 设置开始时间:`, now);
        }
    }
    
    // 修复活跃时钟的标题
    if (!frozenClocks.has(activeClock)) {
        const memoryTitle = document.getElementById(`memoryTitle-${activeClock}`);
        if (memoryTitle && memoryTitle.textContent.includes('NaN')) {
            memoryTitle.textContent = '这段时光里...';
            console.log(`修复时钟 ${activeClock} 的标题`);
        }
    }
    
    // 保存修复后的数据
    saveToLocalStorage();
    console.log('数据修复完成');
}

// 重置到初始状态
function resetToInitialState() {
    if (confirm('确定要重置到初始状态吗？\n这将清除所有记录和定格的时钟，此操作不可撤销！')) {
        console.log('开始重置到初始状态...');
        
        // 清除localStorage数据
        localStorage.removeItem('darkClockData');
        localStorage.removeItem('habitTrackerData');
        localStorage.removeItem('trackerCollapsed');
        
        // 重置所有变量
        lastSecond = -1;
        clockCounter = 0;
        activeClock = 0;
        frozenClocks.clear();
        clockStartTimes.clear();
        
        // 重置习惯追踪器数据
        habitData = {
            firstUseDate: null,
            lastUseDate: null,
            continuousDays: 0,
            totalRecords: 0,
            totalDuration: 0
        };
        
        // 设置初始时钟的开始时间
        const now = new Date();
        clockStartTimes.set(0, now);
        
        // 清除所有时钟容器（除了第一个）
        const clocksContainer = document.getElementById('clocksContainer');
        const allClocks = clocksContainer.querySelectorAll('.clock-container');
        
        // 保留第一个时钟，移除其他所有时钟
        for (let i = 1; i < allClocks.length; i++) {
            allClocks[i].remove();
        }
        
        // 重置第一个时钟到初始状态
        const firstClock = allClocks[0];
        if (firstClock) {
            // 移除frozen类
            firstClock.classList.remove('frozen');
            
            // 重置文本内容
            const memoryTextarea = document.getElementById('memory-0');
            const memoryTitle = document.getElementById('memoryTitle-0');
            const digitalTime = document.getElementById('digitalTime-0');
            const date = document.getElementById('date-0');
            
            if (memoryTextarea) memoryTextarea.value = '';
            if (memoryTitle) memoryTitle.textContent = '这段时光里...';
            if (digitalTime) digitalTime.textContent = '00:00:00';
            if (date) date.textContent = '加载中...';
            
            // 重置指针位置（将在updateClock中自动更新）
            const hourHand = document.getElementById('hourHand-0');
            const minuteHand = document.getElementById('minuteHand-0');
            const secondHand = document.getElementById('secondHand-0');
            
            if (hourHand) hourHand.style.transform = 'rotate(0deg)';
            if (minuteHand) minuteHand.style.transform = 'rotate(0deg)';
            if (secondHand) secondHand.style.transform = 'rotate(0deg)';
        }
        
        console.log('重置完成！');
        
        // 立即更新时钟显示
        updateClock();
        
        // 更新习惯追踪器显示
        updateHabitDisplay();
        
        // 重置追踪器折叠状态
        const trackerSidebar = document.querySelector('.tracker-sidebar');
        const trackerToggle = document.getElementById('trackerToggle');
        const expandBtn = document.getElementById('expandBtn');
        
        if (trackerSidebar) {
            trackerSidebar.classList.remove('collapsed');
        }
        if (trackerToggle) {
            trackerToggle.textContent = '−';
        }
        if (expandBtn) {
            expandBtn.classList.remove('show');
        }
        
        // 滚动到顶部
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        alert('已重置到初始状态！');
    }
}

function updateClock() {
    const now = new Date();
    
    // 获取当前时间
    const hours = now.getHours() % 12; // 12小时制
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    
    // 计算指针角度
    const secondAngle = seconds * 6; // 每秒6度 (360/60)
    const minuteAngle = minutes * 6 + seconds * 0.1; // 每分钟6度 + 秒数的微调
    const hourAngle = hours * 30 + minutes * 0.5; // 每小时30度 + 分钟数的微调
    
    // 更新活跃时钟的指针
    const hourHand = document.getElementById(`hourHand-${activeClock}`);
    const minuteHand = document.getElementById(`minuteHand-${activeClock}`);
    const secondHand = document.getElementById(`secondHand-${activeClock}`);
    
    // 处理秒针的平滑过渡
    if (secondHand && !frozenClocks.has(activeClock)) {
        // 如果从59秒跳到0秒，临时移除过渡效果
        if (lastSecond === 59 && seconds === 0) {
            secondHand.style.transition = 'none';
            secondHand.style.transform = `rotate(${secondAngle}deg)`;
            // 强制重绘后恢复过渡效果
            setTimeout(() => {
                secondHand.style.transition = 'transform 0.1s ease-out';
            }, 50);
        } else {
            secondHand.style.transform = `rotate(${secondAngle}deg)`;
        }
    }
    
    // 应用旋转角度到其他指针（只更新活跃时钟）
    if (hourHand && !frozenClocks.has(activeClock)) {
        hourHand.style.transform = `rotate(${hourAngle}deg)`;
    }
    if (minuteHand && !frozenClocks.has(activeClock)) {
        minuteHand.style.transform = `rotate(${minuteAngle}deg)`;
    }
    
    // 记录上一秒的值
    lastSecond = seconds;
    
    // 更新数字时间显示（只更新活跃时钟）
    const digitalTime = now.toLocaleTimeString('zh-CN', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    
    // 更新日期显示
    const dateOptions = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long'
    };
    const dateString = now.toLocaleDateString('zh-CN', dateOptions);
    
    // 更新页面元素（只更新活跃时钟）
    const digitalTimeElement = document.getElementById(`digitalTime-${activeClock}`);
    const dateElement = document.getElementById(`date-${activeClock}`);
    
    if (digitalTimeElement && !frozenClocks.has(activeClock)) {
        digitalTimeElement.textContent = digitalTime;
    }
    if (dateElement && !frozenClocks.has(activeClock)) {
        dateElement.textContent = dateString;
    }
}

function createClockHTML(clockId) {
    return `
        <div class="clock-container" data-clock-id="${clockId}">
            <div class="clock-section">
                <div class="clock">
                    <!-- 表盘 -->
                    <div class="clock-face">
                        <!-- 分钟刻度 -->
                        <div class="minute-marks">
                            <!-- 每5分钟一个刻度，共12个 -->
                            <div class="minute-mark" style="transform: rotate(0deg)"></div>
                            <div class="minute-mark" style="transform: rotate(30deg)"></div>
                            <div class="minute-mark" style="transform: rotate(60deg)"></div>
                            <div class="minute-mark" style="transform: rotate(90deg)"></div>
                            <div class="minute-mark" style="transform: rotate(120deg)"></div>
                            <div class="minute-mark" style="transform: rotate(150deg)"></div>
                            <div class="minute-mark" style="transform: rotate(180deg)"></div>
                            <div class="minute-mark" style="transform: rotate(210deg)"></div>
                            <div class="minute-mark" style="transform: rotate(240deg)"></div>
                            <div class="minute-mark" style="transform: rotate(270deg)"></div>
                            <div class="minute-mark" style="transform: rotate(300deg)"></div>
                            <div class="minute-mark" style="transform: rotate(330deg)"></div>
                        </div>
                        
                        <!-- 时间刻度 -->
                        <div class="hour-marks">
                            <div class="hour-mark" style="transform: rotate(0deg)"><span>12</span></div>
                            <div class="hour-mark" style="transform: rotate(30deg)"><span>1</span></div>
                            <div class="hour-mark" style="transform: rotate(60deg)"><span>2</span></div>
                            <div class="hour-mark" style="transform: rotate(90deg)"><span>3</span></div>
                            <div class="hour-mark" style="transform: rotate(120deg)"><span>4</span></div>
                            <div class="hour-mark" style="transform: rotate(150deg)"><span>5</span></div>
                            <div class="hour-mark" style="transform: rotate(180deg)"><span>6</span></div>
                            <div class="hour-mark" style="transform: rotate(210deg)"><span>7</span></div>
                            <div class="hour-mark" style="transform: rotate(240deg)"><span>8</span></div>
                            <div class="hour-mark" style="transform: rotate(270deg)"><span>9</span></div>
                            <div class="hour-mark" style="transform: rotate(300deg)"><span>10</span></div>
                            <div class="hour-mark" style="transform: rotate(330deg)"><span>11</span></div>
                        </div>
                        
                        <!-- 指针 -->
                        <div class="hand hour-hand" id="hourHand-${clockId}"></div>
                        <div class="hand minute-hand" id="minuteHand-${clockId}"></div>
                        <div class="hand second-hand" id="secondHand-${clockId}"></div>
                        
                        <!-- 中心点 -->
                        <div class="center-dot"></div>
                    </div>
                </div>
                
                <!-- 数字时间显示 -->
                <div class="digital-time" id="digitalTime-${clockId}">00:00:00</div>
                <div class="date" id="date-${clockId}">加载中...</div>
            </div>
            
            <!-- 记录区域 -->
            <div class="memory-section">
                <div class="memory-title" id="memoryTitle-${clockId}">这段时光里...</div>
                <textarea class="memory-textarea" id="memory-${clockId}" placeholder="记录下这段时间你做了什么，想了什么，或者发生了什么特别的事情..."></textarea>
            </div>
        </div>
    `;
}

function copyCurrentTime(newClockId) {
    // 获取当前活跃时钟的时间显示
    const currentDigitalTime = document.getElementById(`digitalTime-${activeClock}`);
    const currentDate = document.getElementById(`date-${activeClock}`);
    
    // 获取当前活跃时钟的指针角度
    const currentHourHand = document.getElementById(`hourHand-${activeClock}`);
    const currentMinuteHand = document.getElementById(`minuteHand-${activeClock}`);
    const currentSecondHand = document.getElementById(`secondHand-${activeClock}`);
    
    // 设置新时钟的时间显示
    const newDigitalTime = document.getElementById(`digitalTime-${newClockId}`);
    const newDate = document.getElementById(`date-${newClockId}`);
    
    if (currentDigitalTime && newDigitalTime) {
        newDigitalTime.textContent = currentDigitalTime.textContent;
    }
    if (currentDate && newDate) {
        newDate.textContent = currentDate.textContent;
    }
    
    // 复制指针角度到新时钟
    const newHourHand = document.getElementById(`hourHand-${newClockId}`);
    const newMinuteHand = document.getElementById(`minuteHand-${newClockId}`);
    const newSecondHand = document.getElementById(`secondHand-${newClockId}`);
    
    if (currentHourHand && newHourHand) {
        newHourHand.style.transform = currentHourHand.style.transform;
    }
    if (currentMinuteHand && newMinuteHand) {
        newMinuteHand.style.transform = currentMinuteHand.style.transform;
    }
    if (currentSecondHand && newSecondHand) {
        newSecondHand.style.transform = currentSecondHand.style.transform;
    }
}

function formatTimeDuration(startTime, endTime) {
    try {
        // 确保startTime和endTime都是有效的Date对象或时间戳
        const start = startTime instanceof Date ? startTime : new Date(startTime);
        const end = endTime instanceof Date ? endTime : new Date(endTime);
        
        // 检查日期是否有效
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            return "0秒";
        }
        
        const diffMs = end.getTime() - start.getTime();
        
        // 处理负时间差（可能出现在跨天等情况）
        const absDiffMs = Math.abs(diffMs);
        const diffSeconds = Math.floor(absDiffMs / 1000);
        const diffMinutes = Math.floor(diffSeconds / 60);
        const diffHours = Math.floor(diffMinutes / 60);
        
        const hours = diffHours;
        const minutes = diffMinutes % 60;
        const seconds = diffSeconds % 60;
        
        // 如果时间差超过24小时，显示天数
        if (hours >= 24) {
            const days = Math.floor(hours / 24);
            const remainingHours = hours % 24;
            if (remainingHours > 0) {
                return `${days}天${remainingHours}小时${minutes}分`;
            } else {
                return `${days}天${minutes}分`;
            }
        } else if (hours > 0) {
            return `${hours}小时${minutes}分${seconds}秒`;
        } else if (minutes > 0) {
            return `${minutes}分${seconds}秒`;
        } else {
            return `${seconds}秒`;
        }
    } catch (error) {
        console.error('时间差计算错误:', error);
        return "计算错误";
    }
}

function copyClockFunction() {
    const now = new Date();
    
    // 计算当前时钟的持续时间
    let startTime = clockStartTimes.get(activeClock);
    
    // 如果没有开始时间，使用当前时间作为开始时间
    if (!startTime) {
        startTime = now;
        clockStartTimes.set(activeClock, startTime);
        console.warn(`时钟 ${activeClock} 没有开始时间，使用当前时间作为开始时间`);
    }
    
    const duration = formatTimeDuration(startTime, now);
    
    // 获取当前活跃时钟的容器并添加frozen类
    const currentClockContainer = document.querySelector(`[data-clock-id="${activeClock}"]`);
    if (currentClockContainer) {
        currentClockContainer.classList.add('frozen');
        
        // 更新记录区域的标题，显示时间差
        const memoryTitle = document.getElementById(`memoryTitle-${activeClock}`);
        if (memoryTitle) {
            memoryTitle.textContent = `过去的${duration}里...`;
        }
    }
    
    // 定格当前活跃的时钟
    frozenClocks.add(activeClock);
    
    // 创建新时钟
    clockCounter++;
    const newClockId = clockCounter;
    
    // 记录新时钟的开始时间
    clockStartTimes.set(newClockId, now);
    
    // 获取按钮元素
    const copyBtn = document.getElementById('copyClockBtn');
    const clocksContainer = document.getElementById('clocksContainer');
    
    // 添加新时钟到容器（在按钮之前）
    const newClockDiv = document.createElement('div');
    newClockDiv.innerHTML = createClockHTML(newClockId);
    clocksContainer.appendChild(newClockDiv.firstElementChild);
    
    // 复制当前时间到新时钟
    setTimeout(() => {
        copyCurrentTime(newClockId);
        // 设置新时钟为活跃时钟
        activeClock = newClockId;
    }, 50);
    
    // 滚动到按钮位置（因为按钮现在在最新时钟下方）
    setTimeout(() => {
        if (copyBtn) {
            copyBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        // 保存数据到本地存储
        saveToLocalStorage();
    }, 100);
}

// 时间使用图表相关函数
function toggleChart() {
    const chartContainer = document.getElementById('chartContainer');
    const isVisible = chartContainer.style.display !== 'none';
    
    if (isVisible) {
        chartContainer.style.display = 'none';
    } else {
        chartContainer.style.display = 'block';
        updateChart();
    }
}

function closeChart() {
    const chartContainer = document.getElementById('chartContainer');
    chartContainer.style.display = 'none';
}

function updateChart() {
    const chartData = getChartData();
    updateChartStats(chartData);
    updateTimeDistributionChart(chartData);
    updateRecordsList(chartData);
}

function getChartData() {
    const records = [];
    const now = new Date();
    
    // 获取所有时钟的开始时间，按ID排序
    const sortedClockIds = Array.from(clockStartTimes.keys()).sort((a, b) => a - b);
    
    // 为每个时钟创建记录
    sortedClockIds.forEach((clockId, index) => {
        const memoryTextarea = document.getElementById(`memory-${clockId}`);
        const digitalTime = document.getElementById(`digitalTime-${clockId}`);
        const date = document.getElementById(`date-${clockId}`);
        
        if (memoryTextarea && digitalTime && date) {
            const startTime = clockStartTimes.get(clockId);
            
            // 计算结束时间：下一个时钟的开始时间，或者当前时间（如果是最后一个）
            let endTime;
            if (frozenClocks.has(clockId)) {
                // 如果是定格的时钟，结束时间是下一个时钟的开始时间
                const nextClockId = sortedClockIds[index + 1];
                endTime = nextClockId ? clockStartTimes.get(nextClockId) : now;
            } else {
                // 如果是当前活跃的时钟，结束时间是现在
                endTime = now;
            }
            
            if (startTime && endTime) {
                const duration = endTime.getTime() - startTime.getTime();
                const content = memoryTextarea.value.trim();
                
                records.push({
                    id: clockId,
                    startTime: startTime,
                    endTime: endTime,
                    duration: Math.max(0, duration), // 确保不为负数
                    content: content || '未记录内容',
                    timeText: digitalTime.textContent,
                    dateText: date.textContent,
                    isFrozen: frozenClocks.has(clockId),
                    isActive: clockId === activeClock
                });
            }
        }
    });
    
    return records.sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
}

function updateChartStats(records) {
    const totalRecords = records.length;
    const totalDuration = records.reduce((sum, record) => sum + record.duration, 0);
    const avgDuration = totalRecords > 0 ? totalDuration / totalRecords : 0;
    
    document.getElementById('totalRecords').textContent = totalRecords;
    document.getElementById('totalDuration').textContent = formatDuration(totalDuration);
    document.getElementById('avgDuration').textContent = formatDuration(avgDuration);
}

function updateTimeDistributionChart(records) {
    const riverFlow = document.getElementById('riverFlow');
    const flowDuration = document.getElementById('flowDuration');
    const timelineMarks = document.querySelector('.timeline-marks');
    
    // 创建时间刻度 (0-24小时)
    if (!timelineMarks.innerHTML) {
        let marksHTML = '';
        for (let i = 0; i <= 24; i += 4) { // 每4小时一个刻度
            const isMajor = i % 12 === 0; // 0点和12点为主刻度
            marksHTML += `
                <div class="timeline-mark${isMajor ? ' major' : ''}">
                    <div class="mark-line${isMajor ? ' major' : ''}"></div>
                    <div class="mark-text">${i}:00</div>
                </div>
            `;
        }
        timelineMarks.innerHTML = marksHTML;
    }
    
    if (records.length === 0) {
        riverFlow.innerHTML = `
            <div class="river-empty">
                <div class="river-empty-icon">🏞️</div>
                <div>时间之河静静流淌</div>
            </div>
        `;
        flowDuration.textContent = '0分钟';
        return;
    }
    
    // 计算总时长
    const totalDuration = records.reduce((sum, record) => sum + record.duration, 0);
    flowDuration.textContent = formatDuration(totalDuration);
    
    // 创建河流片段
    let flowHTML = '';
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date();
    dayEnd.setHours(23, 59, 59, 999);
    const dayDuration = dayEnd.getTime() - dayStart.getTime();
    
    records.forEach((record, index) => {
        // 计算在一天中的位置百分比
        const startPos = ((record.startTime.getTime() - dayStart.getTime()) / dayDuration) * 100;
        const endPos = ((record.endTime.getTime() - dayStart.getTime()) / dayDuration) * 100;
        const width = Math.max(endPos - startPos, 0.5); // 最小宽度0.5%
        
        const className = record.isActive ? 'active' : 'frozen';
        const startTimeStr = formatTime(record.startTime);
        const endTimeStr = formatTime(record.endTime);
        const durationStr = formatDuration(record.duration);
        
        flowHTML += `
            <div class="flow-segment ${className}" 
                 style="left: ${startPos}%; width: ${width}%;"
                 title="${startTimeStr} - ${endTimeStr}">
                <div class="flow-tooltip">
                    ${startTimeStr} - ${endTimeStr}<br>
                    ${durationStr}
                    ${record.content ? '<br>' + record.content.substring(0, 20) + (record.content.length > 20 ? '...' : '') : ''}
                </div>
            </div>
        `;
    });
    
    riverFlow.innerHTML = flowHTML;
}

function formatTime(date) {
    return date.toLocaleTimeString('zh-CN', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

function updateRecordsList(records) {
    const recordsList = document.getElementById('recordsList');
    
    if (records.length === 0) {
        recordsList.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">🕐</div>
                <div class="empty-state-text">暂无记录</div>
                <div class="empty-state-subtext">开始记录你的时间片段吧</div>
            </div>
        `;
        return;
    }
    
    const recordsHTML = records.map(record => `
        <div class="record-item ${record.isActive ? 'record-active' : 'record-frozen'}">
            <div class="record-info">
                <div class="record-time">
                    ${record.dateText} ${record.timeText}
                    ${record.isActive ? '<span class="record-status active">进行中</span>' : '<span class="record-status frozen">已定格</span>'}
                </div>
                <div class="record-content">${record.content}</div>
            </div>
            <div class="record-duration">${formatDuration(record.duration)}</div>
        </div>
    `).join('');
    
    recordsList.innerHTML = recordsHTML;
}

function formatDuration(milliseconds) {
    if (milliseconds <= 0) return '0秒';
    
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
        const remainingHours = hours % 24;
        return remainingHours > 0 ? `${days}天${remainingHours}小时` : `${days}天`;
    } else if (hours > 0) {
        const remainingMinutes = minutes % 60;
        return remainingMinutes > 0 ? `${hours}小时${remainingMinutes}分` : `${hours}小时`;
    } else if (minutes > 0) {
        const remainingSeconds = seconds % 60;
        return remainingSeconds > 0 ? `${minutes}分${remainingSeconds}秒` : `${minutes}分`;
    } else {
        return `${seconds}秒`;
    }
}

// 习惯追踪器相关功能
let habitData = {
    firstUseDate: null,
    lastUseDate: null,
    continuousDays: 0,
    totalRecords: 0,
    totalDuration: 0
};

function initHabitTracker() {
    // 从localStorage加载习惯数据
    const savedHabitData = localStorage.getItem('habitTrackerData');
    if (savedHabitData) {
        habitData = { ...habitData, ...JSON.parse(savedHabitData) };
        // 确保日期是Date对象
        if (habitData.firstUseDate) habitData.firstUseDate = new Date(habitData.firstUseDate);
        if (habitData.lastUseDate) habitData.lastUseDate = new Date(habitData.lastUseDate);
    }
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // 如果是第一次使用，记录首次使用日期
    if (!habitData.firstUseDate) {
        habitData.firstUseDate = new Date(today);
        habitData.lastUseDate = new Date(today);
        habitData.continuousDays = 1;
    } else {
        // 检查连续天数
        updateContinuousDays(today);
    }
    
    // 绑定折叠/展开功能
    const trackerToggle = document.getElementById('trackerToggle');
    const expandBtn = document.getElementById('expandBtn');
    
    if (trackerToggle) {
        trackerToggle.addEventListener('click', toggleTracker);
    }
    
    if (expandBtn) {
        expandBtn.addEventListener('click', toggleTracker);
    }
    
    updateHabitDisplay();
    
    // 加载折叠状态
    loadTrackerState();
}

function updateContinuousDays(today) {
    const lastUse = new Date(habitData.lastUseDate);
    lastUse.setHours(0, 0, 0, 0);
    
    const daysDiff = Math.floor((today.getTime() - lastUse.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysDiff === 0) {
        // 今天已经使用过了，保持连续天数
        return;
    } else if (daysDiff === 1) {
        // 连续使用
        habitData.continuousDays += 1;
        habitData.lastUseDate = new Date(today);
    } else {
        // 中断了，重新开始
        habitData.continuousDays = 1;
        habitData.lastUseDate = new Date(today);
    }
}

function recordHabitActivity() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // 更新连续天数
    updateContinuousDays(today);
    
    // 增加总记录数
    habitData.totalRecords += 1;
    
    // 保存数据
    saveHabitData();
    
    // 更新显示
    updateHabitDisplay();
    
    // 检查里程碑
    checkMilestones();
}

function updateHabitDisplay() {
    // 计算总时长
    const records = getChartData();
    const totalDuration = records.reduce((sum, record) => sum + record.duration, 0);
    habitData.totalDuration = totalDuration;
    
    // 计算今日记录数
    const today = new Date();
    const todayRecords = records.filter(record => {
        const recordDate = new Date(record.startTime);
        return recordDate.toDateString() === today.toDateString();
    });
    
    // 更新显示
    document.getElementById('continuousDays').textContent = habitData.continuousDays;
    document.getElementById('todayRecords').textContent = todayRecords.length;
    
    // 格式化总时长显示
    const totalTimeElement = document.getElementById('totalTime');
    if (totalDuration < 60 * 60 * 1000) { // 小于1小时
        totalTimeElement.textContent = Math.round(totalDuration / (1000 * 60)) + '分';
    } else {
        const hours = Math.floor(totalDuration / (1000 * 60 * 60));
        const minutes = Math.round((totalDuration % (1000 * 60 * 60)) / (1000 * 60));
        totalTimeElement.textContent = hours + '时' + (minutes > 0 ? minutes + '分' : '');
    }
}

function checkMilestones() {
    const milestones = [
        { type: 'days', value: 3, text: '🌱 坚持3天，习惯开始萌芽' },
        { type: 'days', value: 7, text: '⭐ 坚持一周，时间意识觉醒' },
        { type: 'days', value: 21, text: '🎯 坚持21天，习惯初步养成' },
        { type: 'days', value: 30, text: '🏆 坚持一月，时间管理达人' },
        { type: 'records', value: 10, text: '📝 第10次记录，专注力提升' },
        { type: 'records', value: 50, text: '🎨 第50次记录，时光艺术家' },
        { type: 'records', value: 100, text: '💎 第100次记录，时间珍惜大师' },
        { type: 'time', value: 10 * 60 * 60 * 1000, text: '⏰ 累计10小时，时间感知深化' },
        { type: 'time', value: 50 * 60 * 60 * 1000, text: '🌟 累计50小时，时间智慧升华' },
        { type: 'time', value: 100 * 60 * 60 * 1000, text: '👑 累计100小时，时间哲学家' }
    ];
    
    const milestoneContainer = document.getElementById('milestoneContainer');
    const milestoneText = document.getElementById('milestoneText');
    
    for (const milestone of milestones) {
        let achieved = false;
        
        switch (milestone.type) {
            case 'days':
                achieved = habitData.continuousDays === milestone.value;
                break;
            case 'records':
                achieved = habitData.totalRecords === milestone.value;
                break;
            case 'time':
                achieved = habitData.totalDuration >= milestone.value && 
                          habitData.totalDuration < milestone.value + (10 * 60 * 1000); // 10分钟容差
                break;
        }
        
        if (achieved) {
            milestoneText.textContent = milestone.text;
            milestoneContainer.style.display = 'block';
            milestoneContainer.style.animation = 'milestoneGlow 1.5s ease-in-out';
            
            // 5秒后淡出隐藏
            setTimeout(() => {
                milestoneContainer.style.opacity = '0';
                milestoneContainer.style.transition = 'opacity 1s ease';
                setTimeout(() => {
                    milestoneContainer.style.display = 'none';
                    milestoneContainer.style.opacity = '';
                    milestoneContainer.style.transition = '';
                    milestoneContainer.style.animation = '';
                }, 1000);
            }, 4000);
            break;
        }
    }
}

function toggleTracker() {
    const trackerSidebar = document.querySelector('.tracker-sidebar');
    const trackerToggle = document.getElementById('trackerToggle');
    const expandBtn = document.getElementById('expandBtn');
    
    if (trackerSidebar.classList.contains('collapsed')) {
        // 展开
        trackerSidebar.classList.remove('collapsed');
        trackerToggle.textContent = '−';
        expandBtn.classList.remove('show');
    } else {
        // 收缩
        trackerSidebar.classList.add('collapsed');
        trackerToggle.textContent = '→';
        expandBtn.classList.add('show');
    }
    
    // 保存折叠状态
    localStorage.setItem('trackerCollapsed', trackerSidebar.classList.contains('collapsed'));
}

function saveHabitData() {
    localStorage.setItem('habitTrackerData', JSON.stringify(habitData));
}

function loadTrackerState() {
    const isCollapsed = localStorage.getItem('trackerCollapsed') === 'true';
    const trackerSidebar = document.querySelector('.tracker-sidebar');
    const trackerToggle = document.getElementById('trackerToggle');
    const expandBtn = document.getElementById('expandBtn');
    
    if (isCollapsed) {
        trackerSidebar.classList.add('collapsed');
        trackerToggle.textContent = '→';
        expandBtn.classList.add('show');
    }
}

// 修改原有的copyClockFunction，添加习惯追踪
const originalCopyClockFunction = copyClockFunction;
copyClockFunction = function() {
    // 调用原有的定格功能
    originalCopyClockFunction();
    
    // 记录习惯活动
    recordHabitActivity();
};

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 尝试从本地存储加载数据
    const dataLoaded = loadFromLocalStorage();
    
    if (!dataLoaded) {
        // 如果没有保存的数据，记录初始时钟的开始时间
        clockStartTimes.set(0, new Date());
    }
    
    // 绑定按钮事件
    const copyBtn = document.getElementById('copyClockBtn');
    const resetBtn = document.getElementById('resetBtn');
    const chartToggleBtn = document.getElementById('chartToggleBtn');
    const chartCloseBtn = document.getElementById('chartCloseBtn');
    const focusToggleBtn = document.getElementById('focusToggleBtn');
    const focusCloseBtn = document.getElementById('focusCloseBtn');
    
    if (copyBtn) {
        copyBtn.addEventListener('click', copyClockFunction);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', resetToInitialState);
    }
    
    if (chartToggleBtn) {
        chartToggleBtn.addEventListener('click', toggleChart);
    }
    
    if (chartCloseBtn) {
        chartCloseBtn.addEventListener('click', closeChart);
    }
    
    if (focusToggleBtn) {
        focusToggleBtn.addEventListener('click', toggleFocus);
    }
    
    if (focusCloseBtn) {
        focusCloseBtn.addEventListener('click', closeFocus);
    }
    
    // 设置自动保存
    setupAutoSave();
    
    // 初始化习惯追踪器
    initHabitTracker();
    loadTrackerState();
    
    // 初始化专注时光
    initFocus();
    
    // 修复可能的数据问题
    setTimeout(() => {
        repairClockData();
        showDataInfo();
        updateHabitDisplay(); // 更新习惯追踪显示
    }, 1000);
    
    // 立即更新一次
    updateClock();
    
    // 每秒更新一次
    setInterval(updateClock, 1000);
    
    // 每分钟更新一次习惯追踪显示
    setInterval(updateHabitDisplay, 60000);
});

// 专注时光功能
let focusState = {
    isRunning: false,
    isPaused: false,
    currentMode: 'work', // work, shortBreak, longBreak
    duration: 25 * 60 * 1000, // 25分钟 (毫秒)
    remainingTime: 25 * 60 * 1000,
    startTime: null,
    interval: null,
    currentTask: '',
    
    // 统计数据
    todayFocusCount: 0,
    todayFocusTime: 0,
    totalFocusCount: 0,
    totalFocusTime: 0,
    currentStreak: 0,
    lastActiveDate: null,
    
    // 设置
    workDuration: 25 * 60 * 1000,
    shortBreakDuration: 5 * 60 * 1000,
    longBreakDuration: 15 * 60 * 1000,
    longBreakInterval: 4 // 每4个专注周期后长休息
};

function initFocus() {
    // 加载保存的数据
    loadFocusData();
    
    // 绑定事件
    bindFocusEvents();
    
    // 更新显示
    updateFocusDisplay();
    updateFocusStats();
    
    // 初始化任务显示
    const taskContentEl = document.getElementById('taskContent');
    if (taskContentEl && focusState.currentTask) {
        taskContentEl.innerHTML = `<div class="task-text">${focusState.currentTask}</div>`;
    }
}

function loadFocusData() {
    try {
        const savedData = localStorage.getItem('focusData');
        if (savedData) {
            const data = JSON.parse(savedData);
            
            // 合并数据，保留默认值
            focusState = { ...focusState, ...data };
            
            // 重置运行状态（刷新后不继续运行）
            focusState.isRunning = false;
            focusState.isPaused = false;
            focusState.interval = null;
            
            // 检查是否是新的一天
            const today = new Date().toDateString();
            if (focusState.lastActiveDate !== today) {
                focusState.todayFocusCount = 0;
                focusState.todayFocusTime = 0;
                focusState.lastActiveDate = today;
            }
        }
    } catch (error) {
        console.error('加载专注时光数据失败:', error);
    }
}

function saveFocusData() {
    try {
        // 不保存运行时状态
        const dataToSave = { ...focusState };
        delete dataToSave.interval;
        delete dataToSave.startTime;
        
        localStorage.setItem('focusData', JSON.stringify(dataToSave));
    } catch (error) {
        console.error('保存专注时光数据失败:', error);
    }
}

function bindFocusEvents() {
    // 计时器控制按钮
    const startBtn = document.getElementById('focusStartBtn');
    const pauseBtn = document.getElementById('focusPauseBtn');
    const resetBtn = document.getElementById('focusResetBtn');
    
    if (startBtn) {
        startBtn.addEventListener('click', startFocus);
    }
    
    if (pauseBtn) {
        pauseBtn.addEventListener('click', pauseFocus);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', resetFocus);
    }
    
    // 模式切换按钮
    const modeBtns = document.querySelectorAll('.mode-dot');
    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (!focusState.isRunning) {
                switchFocusMode(btn.dataset.mode, parseInt(btn.dataset.duration));
            }
        });
    });
    
    // 任务相关按钮
    const taskEditBtn = document.getElementById('taskEditBtn');
    const taskSaveBtn = document.getElementById('taskSave');
    const taskCancelBtn = document.getElementById('taskCancel');
    const taskField = document.getElementById('taskField');
    const taskContent = document.getElementById('taskContent');
    
    if (taskEditBtn) {
        taskEditBtn.addEventListener('click', showTaskEdit);
    }
    
    if (taskContent) {
        taskContent.addEventListener('click', showTaskEdit);
    }
    
    if (taskSaveBtn) {
        taskSaveBtn.addEventListener('click', saveTask);
    }
    
    if (taskCancelBtn) {
        taskCancelBtn.addEventListener('click', cancelTaskEdit);
    }
    
    if (taskField) {
        taskField.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                saveTask();
            }
        });
    }
}

function toggleFocus() {
    const focusContainer = document.getElementById('focusContainer');
    if (focusContainer) {
        focusContainer.style.display = 'flex';
        updateFocusDisplay();
        updateFocusStats();
    }
}

function closeFocus() {
    const focusContainer = document.getElementById('focusContainer');
    if (focusContainer) {
        focusContainer.style.display = 'none';
    }
}

function startFocus() {
    if (focusState.isPaused) {
        // 从暂停状态恢复
        focusState.isPaused = false;
        focusState.isRunning = true;
        focusState.startTime = Date.now() - (focusState.duration - focusState.remainingTime);
    } else {
        // 全新开始
        focusState.isRunning = true;
        focusState.isPaused = false;
        focusState.startTime = Date.now();
        focusState.remainingTime = focusState.duration;
    }
    
    // 启动计时器
    focusState.interval = setInterval(updateFocusTimer, 1000);
    
    updateFocusButtons();
    
    // 播放开始音效（如果需要）
    playNotificationSound('start');
}

function pauseFocus() {
    focusState.isRunning = false;
    focusState.isPaused = true;
    
    if (focusState.interval) {
        clearInterval(focusState.interval);
        focusState.interval = null;
    }
    
    updateFocusButtons();
    saveFocusData();
}

function resetFocus() {
    focusState.isRunning = false;
    focusState.isPaused = false;
    focusState.remainingTime = focusState.duration;
    
    if (focusState.interval) {
        clearInterval(focusState.interval);
        focusState.interval = null;
    }
    
    updateFocusDisplay();
    updateFocusButtons();
    saveFocusData();
}

function updateFocusTimer() {
    const now = Date.now();
    const elapsed = now - focusState.startTime;
    focusState.remainingTime = Math.max(0, focusState.duration - elapsed);
    
    if (focusState.remainingTime <= 0) {
        // 时间到了
        completeFocus();
        return;
    }
    
    updateFocusDisplay();
}

function completeFocus() {
    // 停止计时器
    focusState.isRunning = false;
    focusState.isPaused = false;
    
    if (focusState.interval) {
        clearInterval(focusState.interval);
        focusState.interval = null;
    }
    
    // 记录统计
    if (focusState.currentMode === 'work') {
        focusState.todayFocusCount++;
        focusState.totalFocusCount++;
        focusState.todayFocusTime += Math.floor(focusState.duration / (1000 * 60));
        focusState.totalFocusTime += Math.floor(focusState.duration / (1000 * 60));
        
        // 记录到暗时钟系统
        recordFocusToHabit();
    }
    
    // 播放完成音效
    playNotificationSound('complete');
    
    // 显示完成通知
    showFocusNotification();
    
    // 自动切换模式
    autoSwitchFocusMode();
    
    // 保存数据
    saveFocusData();
    
    // 更新显示
    updateFocusStats();
}

function updateFocusDisplay() {
    // 更新时间显示
    const minutes = Math.floor(focusState.remainingTime / (1000 * 60));
    const seconds = Math.floor((focusState.remainingTime % (1000 * 60)) / 1000);
    const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    const focusTime = document.getElementById('focusTime');
    if (focusTime) {
        focusTime.textContent = timeString;
    }
    
    // 更新模式显示
    const focusMode = document.getElementById('focusMode');
    if (focusMode) {
        const modeTexts = {
            work: '专注',
            shortBreak: '短憩',
            longBreak: '长憩'
        };
        focusMode.textContent = modeTexts[focusState.currentMode] || '专注';
    }
    
    // 更新进度条
    const progress = 1 - (focusState.remainingTime / focusState.duration);
    const circumference = 2 * Math.PI * 50; // r=50
    const offset = circumference * (1 - progress);
    
    const progressCircle = document.getElementById('focusProgress');
    if (progressCircle) {
        progressCircle.style.strokeDasharray = circumference;
        progressCircle.style.strokeDashoffset = offset;
    }
    
    // 更新页面标题（如果专注时光在运行）
    if (focusState.isRunning) {
        document.title = `${timeString} - 专注时光 - 暗时钟`;
    } else {
        document.title = '暗时钟';
    }
}

function updateFocusButtons() {
    const startBtn = document.getElementById('focusStartBtn');
    const pauseBtn = document.getElementById('focusPauseBtn');
    
    if (focusState.isRunning) {
        if (startBtn) startBtn.style.display = 'none';
        if (pauseBtn) pauseBtn.style.display = 'inline-block';
    } else {
        if (startBtn) startBtn.style.display = 'inline-block';
        if (pauseBtn) pauseBtn.style.display = 'none';
    }
}

function updateFocusStats() {
    // 更新今日统计
    const todayFocusCountEl = document.getElementById('todayFocusCount');
    const todayFocusMinutesEl = document.getElementById('todayFocusMinutes');
    const focusStreakEl = document.getElementById('focusStreak');
    
    if (todayFocusCountEl) {
        todayFocusCountEl.textContent = focusState.todayFocusCount;
    }
    
    if (todayFocusMinutesEl) {
        todayFocusMinutesEl.textContent = focusState.todayFocusTime + '分';
    }
    
    if (focusStreakEl) {
        focusStreakEl.textContent = focusState.currentStreak;
    }
}

function switchFocusMode(mode, duration) {
    focusState.currentMode = mode;
    focusState.duration = duration * 60 * 1000;
    focusState.remainingTime = focusState.duration;
    
    // 更新模式按钮状态
    document.querySelectorAll('.mode-dot').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.mode === mode) {
            btn.classList.add('active');
        }
    });
    
    updateFocusDisplay();
    updateFocusButtons();
    saveFocusData();
}

function autoSwitchFocusMode() {
    if (focusState.currentMode === 'work') {
        // 工作完成，切换到休息
        if (focusState.todayFocusCount % focusState.longBreakInterval === 0) {
            // 长休息
            switchFocusMode('longBreak', focusState.longBreakDuration / (1000 * 60));
        } else {
            // 短休息
            switchFocusMode('shortBreak', focusState.shortBreakDuration / (1000 * 60));
        }
    } else {
        // 休息完成，切换到工作
        switchFocusMode('work', focusState.workDuration / (1000 * 60));
    }
}

function recordFocusToHabit() {
    // 将专注时光记录集成到原有的习惯追踪系统
    recordHabitActivity();
}

function showTaskEdit() {
    const taskInputArea = document.getElementById('taskInputArea');
    const taskContent = document.getElementById('taskContent');
    const taskField = document.getElementById('taskField');
    
    if (taskInputArea && taskContent) {
        taskInputArea.style.display = 'block';
        taskContent.style.display = 'none';
        if (taskField) {
            taskField.value = focusState.currentTask || '';
            taskField.focus();
        }
    }
}

function saveTask() {
    const taskField = document.getElementById('taskField');
    const taskContent = document.getElementById('taskContent');
    const taskInputArea = document.getElementById('taskInputArea');
    
    if (taskField && taskContent) {
        const taskText = taskField.value.trim();
        if (taskText) {
            focusState.currentTask = taskText;
            taskContent.innerHTML = `<div class="task-text">${taskText}</div>`;
        } else {
            focusState.currentTask = '';
            taskContent.innerHTML = '<div class="task-placeholder">点击添加要专注的事情</div>';
        }
        
        // 保存数据
        saveFocusData();
        
        if (taskInputArea) {
            taskInputArea.style.display = 'none';
        }
        taskContent.style.display = 'block';
    }
}

function cancelTaskEdit() {
    const taskInputArea = document.getElementById('taskInputArea');
    const taskContent = document.getElementById('taskContent');
    
    if (taskInputArea && taskContent) {
        taskInputArea.style.display = 'none';
        taskContent.style.display = 'block';
    }
}

function showFocusNotification() {
    // 简单的通知显示
    const modeTexts = {
        work: '专注时间结束！该休息一下了',
        shortBreak: '短休息结束！继续专注工作',
        longBreak: '长休息结束！准备新的专注时段'
    };
    
    const message = modeTexts[focusState.currentMode] || '专注完成！';
    
    // 可以用浏览器通知API（如果用户允许）
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('专注时光', {
            body: message,
            icon: '/favicon.ico'
        });
    } else {
        console.log(message);
    }
}





function playNotificationSound(type) {
    // 简单的音效提示（可以用Web Audio API实现更好的效果）
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        if (type === 'complete') {
            // 完成音效：高音
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
            oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.2);
        } else {
            // 开始音效：低音
            oscillator.frequency.setValueAtTime(400, audioContext.currentTime);
        }
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    } catch (error) {
        // 音效播放失败时静默处理
        console.log('音效播放失败:', error);
    }
}

// 页面可见性变化时的处理
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // 页面隐藏时继续计时，但可以降低更新频率
        if (focusState.isRunning && focusState.interval) {
            clearInterval(focusState.interval);
            focusState.interval = setInterval(updateFocusTimer, 5000); // 5秒更新一次
        }
    } else {
        // 页面可见时恢复正常更新频率
        if (focusState.isRunning && focusState.interval) {
            clearInterval(focusState.interval);
            focusState.interval = setInterval(updateFocusTimer, 1000); // 1秒更新一次
            updateFocusDisplay(); // 立即更新显示
        }
    }
});

// 请求通知权限（在用户首次交互时）
document.addEventListener('click', function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
    document.removeEventListener('click', requestNotificationPermission);
}, { once: true }); 