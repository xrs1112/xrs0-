// DOM元素
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.nav-menu');
const backToTop = document.getElementById('backToTop');
const ctaButton = document.querySelector('.cta-button');

// 商品相关元素
const productsGrid = document.getElementById('productsGrid');
const categoryFilters = document.getElementById('categoryFilters');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const sortSelect = document.getElementById('sortSelect');
const loadingIndicator = document.getElementById('loadingIndicator');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const noMoreProducts = document.getElementById('noMoreProducts');
const noProductsFound = document.getElementById('noProductsFound');
const productsStats = document.getElementById('productsStats');
const statsText = document.getElementById('statsText');

// 商品管理状态
let currentPage = 1;
let currentCategory = 'all';
let currentSearch = '';
let currentSort = '';
let isLoading = false;
let hasMoreProducts = true;

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

async function initializeApp() {
    try {
        // 加载分类
        await loadCategories();
        // 加载商品
        await loadProducts(true);
        // 绑定事件
        bindEvents();
        // 初始化主题切换功能
        initThemeToggle();
        // 页面加载完成效果
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.5s ease';
        setTimeout(() => {
            document.body.style.opacity = '1';
        }, 100);
    } catch (error) {
        console.error('应用初始化失败:', error);
        showError('网站初始化失败，请刷新页面重试');
    }
}

// 加载商品分类
async function loadCategories() {
    try {
        const response = await fetch('http://localhost:3001/api/categories');
        const result = await response.json();
        
        if (result.success) {
            renderCategories(result.data);
        }
    } catch (error) {
        console.error('加载分类失败:', error);
    }
}

// 渲染分类按钮
function renderCategories(categories) {
    const allButton = categoryFilters.querySelector('[data-category="all"]');
    
    categories.forEach(category => {
        const button = document.createElement('button');
        button.className = 'filter-btn';
        button.setAttribute('data-category', category.name);
        button.textContent = `${category.name} (${category.count})`;
        categoryFilters.appendChild(button);
    });
}

// 加载商品
async function loadProducts(reset = false) {
    if (isLoading) return;
    
    isLoading = true;
    showLoadingState();
    
    try {
        const params = new URLSearchParams({
            page: reset ? 1 : currentPage,
            limit: 8,
            category: currentCategory,
            search: currentSearch,
            sort: currentSort
        });
        
        const response = await fetch(`http://localhost:3001/api/products?${params}`);
        const result = await response.json();
        
        if (result.success) {
            if (reset) {
                currentPage = 1;
                productsGrid.innerHTML = '';
            }
            
            renderProducts(result.data);
            updatePagination(result.pagination);
            updateStats(result.pagination);
            
            currentPage++;
        } else {
            showError('加载手串失败');
        }
    } catch (error) {
        console.error('加载手串失败:', error);
        showError('网络错误，请检查连接');
    } finally {
        isLoading = false;
        hideLoadingState();
    }
}

// 渲染商品
function renderProducts(products) {
    if (products.length === 0 && currentPage === 1) {
        showNoProductsFound();
        return;
    }
    
    hideNoProductsFound();
    
    products.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
        
        // 添加进入动画
        setTimeout(() => {
            productCard.style.opacity = '1';
            productCard.style.transform = 'translateY(0)';
        }, 100);
    });
}

// 创建商品卡片
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'all 0.6s ease';
    
    // 创建标签HTML
    let tagsHtml = '';
    if (product.hot || product.new) {
        tagsHtml = '<div class="product-tags">';
        if (product.hot) {
            tagsHtml += '<span class="product-tag hot">热门</span>';
        }
        if (product.new) {
            tagsHtml += '<span class="product-tag new">新品</span>';
        }
        tagsHtml += '</div>';
    }
    
    card.innerHTML = `
        <div class="product-image">
            ${tagsHtml}
            <div class="media-placeholder">
                <div class="placeholder-content">
                    <div class="placeholder-icon">🖼️</div>
                    <p>${product.image}</p>
                </div>
            </div>
            <div class="product-overlay">
                <button class="quick-view-btn" data-product-id="${product.id}">快速查看</button>
            </div>
        </div>
        <div class="product-info">
            <h3>${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-price">
                <span class="current-price">¥${product.currentPrice}</span>
                <span class="original-price">¥${product.originalPrice}</span>
            </div>
            <button class="add-to-cart-btn" data-product-id="${product.id}">加入购物车</button>
        </div>
    `;
    
    return card;
}

// 更新分页状态
function updatePagination(pagination) {
    hasMoreProducts = pagination.hasNext;
    
    if (hasMoreProducts) {
        showLoadMoreButton();
    } else {
        showNoMoreProducts();
    }
}

// 更新统计信息
function updateStats(pagination) {
    const { totalItems, currentPage, totalPages } = pagination;
    const currentlyShowing = Math.min(currentPage * pagination.itemsPerPage, totalItems);
    
    if (totalItems === 0) {
        statsText.textContent = '未找到符合条件的手串';
    } else {
        statsText.textContent = `显示 ${currentlyShowing} / ${totalItems} 件手串 (第 ${currentPage} / ${totalPages} 页)`;
    }
}

// 显示/隐藏状态元素
function showLoadingState() {
    loadingIndicator.style.display = 'flex';
    loadMoreBtn.style.display = 'none';
    noMoreProducts.style.display = 'none';
    noProductsFound.style.display = 'none';
}

function hideLoadingState() {
    loadingIndicator.style.display = 'none';
}

function showLoadMoreButton() {
    loadMoreBtn.style.display = 'flex';
    noMoreProducts.style.display = 'none';
}

function showNoMoreProducts() {
    loadMoreBtn.style.display = 'none';
    noMoreProducts.style.display = 'block';
}

function showNoProductsFound() {
    noProductsFound.style.display = 'block';
    loadMoreBtn.style.display = 'none';
    noMoreProducts.style.display = 'none';
}

function hideNoProductsFound() {
    noProductsFound.style.display = 'none';
}

function showError(message) {
    alert(message); // 可以后续改为更优雅的错误提示
}

// 绑定事件
function bindEvents() {
    // 导航相关事件
    bindNavigationEvents();
    
    // 分类筛选
    categoryFilters.addEventListener('click', (e) => {
        if (e.target.classList.contains('filter-btn')) {
            handleCategoryFilter(e.target);
        }
    });
    
    // 搜索功能
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // 排序功能
    sortSelect.addEventListener('change', handleSort);
    
    // 加载更多
    loadMoreBtn.addEventListener('click', () => {
        loadProducts(false);
    });
    
    // 商品操作事件委托
    productsGrid.addEventListener('click', (e) => {
        if (e.target.classList.contains('quick-view-btn')) {
            handleQuickView(e.target.dataset.productId);
        } else if (e.target.classList.contains('add-to-cart-btn')) {
            handleAddToCart(e.target.dataset.productId);
        }
    });
}

// 导航相关事件
function bindNavigationEvents() {
    // 移动端导航菜单切换
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('active');
        });
    }

    // 点击导航链接后关闭移动端菜单
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            navToggle.classList.remove('active');
        });
    });

    // 平滑滚动到指定锚点
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offsetTop = target.offsetTop - 70;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

    // 返回顶部按钮显示/隐藏
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });

    // 返回顶部功能
    if (backToTop) {
        backToTop.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // CTA按钮点击事件
    if (ctaButton) {
        ctaButton.addEventListener('click', () => {
            const productsSection = document.getElementById('products');
            const offsetTop = productsSection.offsetTop - 70;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        });
    }

    // 导航栏滚动效果
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            const isDarkTheme = document.body.classList.contains('dark-theme');
            if (window.scrollY > 50) {
                if (isDarkTheme) {
                    navbar.style.background = 'rgba(26, 26, 26, 0.98)';
                    navbar.style.boxShadow = '0 2px 25px rgba(0, 0, 0, 0.4)';
                } else {
                    navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                    navbar.style.boxShadow = '0 2px 25px rgba(0, 0, 0, 0.15)';
                }
            } else {
                if (isDarkTheme) {
                    navbar.style.background = 'rgba(26, 26, 26, 0.95)';
                    navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.3)';
                } else {
                    navbar.style.background = 'rgba(255, 255, 255, 0.95)';
                    navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
                }
            }
        }
    });
}

// 处理分类筛选
function handleCategoryFilter(button) {
    // 更新按钮状态
    categoryFilters.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    button.classList.add('active');
    
    // 更新筛选状态
    currentCategory = button.dataset.category;
    currentPage = 1;
    
    // 重新加载商品
    loadProducts(true);
}

// 处理搜索
function handleSearch() {
    const searchTerm = searchInput.value.trim();
    currentSearch = searchTerm;
    currentPage = 1;
    
    // 重新加载商品
    loadProducts(true);
}

// 处理排序
function handleSort() {
    currentSort = sortSelect.value;
    currentPage = 1;
    
    // 重新加载商品
    loadProducts(true);
}

// 处理快速查看 - 跳转到详情页面
function handleQuickView(productId) {
    // 跳转到商品详情页面，传递商品ID参数
    window.location.href = `product-detail.html?id=${productId}`;
}

// 处理加入购物车
async function handleAddToCart(productId) {
    try {
        const response = await fetch('http://localhost:3001/api/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                productId: parseInt(productId),
                quantity: 1
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 添加视觉反馈
            const button = document.querySelector(`[data-product-id="${productId}"].add-to-cart-btn`);
            if (button) {
                button.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    button.style.transform = 'scale(1)';
                }, 150);
            }
            
            alert('手串已加入购物车！');
        } else {
            alert(result.message || '加入购物车失败');
        }
    } catch (error) {
        console.error('加入购物车失败:', error);
        alert('加入购物车失败');
    }
}

// 联系表单处理
const contactForm = document.querySelector('.contact-form form');
if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(contactForm);
        const name = contactForm.querySelector('input[type="text"]').value;
        const email = contactForm.querySelector('input[type="email"]').value;
        const message = contactForm.querySelector('textarea').value;
        
        if (name && email && message) {
            try {
                const response = await fetch('http://localhost:3001/api/contact', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ name, email, message })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert(result.message);
                    contactForm.reset();
                } else {
                    alert(result.message || '发送失败');
                }
            } catch (error) {
                console.error('发送联系表单失败:', error);
                alert('发送失败，请稍后重试');
            }
        } else {
            alert('请填写所有必填字段。');
        }
    });
}

// 防抖函数
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 社交媒体链接处理
document.querySelectorAll('.social-links a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const platform = link.textContent;
        alert(`即将跳转到${platform}页面`);
    });
});

// 夜间模式功能
function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle?.querySelector('.theme-icon');
    
    // 确保按钮图标与当前主题状态一致（主题已在HTML中设置）
    const isDarkTheme = document.body.classList.contains('dark-theme');
    if (themeIcon) {
        themeIcon.textContent = isDarkTheme ? '☀️' : '🌙';
    }
    
    // 主题切换事件监听器
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            
            const isDark = document.body.classList.contains('dark-theme');
            
            // 更新按钮图标
            if (themeIcon) {
                themeIcon.textContent = isDark ? '☀️' : '🌙';
            }
            
            // 保存主题设置到localStorage
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            
            // 添加切换动画效果
            themeToggle.style.transform = 'scale(0.9)';
            setTimeout(() => {
                themeToggle.style.transform = 'scale(1)';
            }, 150);
            
            // 更新导航栏背景色
            updateNavbarTheme(isDark);
        });
    }
}

// 更新导航栏主题
function updateNavbarTheme(isDark) {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (isDark) {
            navbar.style.background = 'rgba(26, 26, 26, 0.95)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.3)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        }
    }
}

