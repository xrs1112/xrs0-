﻿// 商品详情页面JavaScript功能

class ProductDetail {
    constructor() {
        this.currentProduct = null;
        this.init();
    }

    init() {
        this.loadProduct();
        this.setupEventListeners();
        this.setupTabs();
    }

    async loadProduct() {
        const urlParams = new URLSearchParams(window.location.search);
        const productId = urlParams.get('id');
        
        if (!productId) {
            this.showError();
            return;
        }

        try {
            this.showLoading();
            const response = await fetch(`http://localhost:3001/api/products/${productId}`);
            const product = await response.json();
            this.currentProduct = product;
            this.renderProduct(product);
            this.hideLoading();
        } catch (error) {
            console.error('加载手串失败:', error);
            this.showError();
        }
    }

    showLoading() {
        document.getElementById('loadingState').style.display = 'block';
        document.getElementById('productDetailContent').style.display = 'none';
    }

    hideLoading() {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('productDetailContent').style.display = 'block';
    }

    showError() {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('errorState').style.display = 'block';
    }

    renderProduct(product) {
        document.title = `${product.name} - 超好玩奥文玩`;
        document.getElementById('productTitle').textContent = product.name;
        document.getElementById('currentPrice').textContent = `¥${product.price}`;
        document.getElementById('productDescription').textContent = product.description;
        document.getElementById('productCategory').textContent = product.category;
        document.getElementById('mainImageText').textContent = `${product.name} - 主图`;
    }

    setupEventListeners() {
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', () => {
                alert('已加入购物车！');
            });
        }
    }

    setupTabs() {
        const tabHeaders = document.querySelectorAll('.tab-header');
        const tabContents = document.querySelectorAll('.tab-content');

        tabHeaders.forEach(header => {
            header.addEventListener('click', () => {
                const targetTab = header.getAttribute('data-tab');
                tabHeaders.forEach(h => h.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                header.classList.add('active');
                const targetContent = document.getElementById(targetTab);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new ProductDetail();
    initThemeToggle();
});

// 夜间模式功能
function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = themeToggle?.querySelector('.theme-icon');
    
    // 确保按钮图标与当前主题状态一致（主题已在HTML中设置）
    const isDarkTheme = document.body.classList.contains('dark-theme');
    if (themeIcon) {
        themeIcon.textContent = isDarkTheme ? '☀️' : '🌙';
    }
    
    // 初始化时更新导航栏主题
    updateNavbarTheme(isDarkTheme);
    
    // 主题切换事件监听器
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            
            const isDark = document.body.classList.contains('dark-theme');
            
            // 更新按钮图标
            if (themeIcon) {
                themeIcon.textContent = isDark ? '☀️' : '🌙';
            }
            
            // 保存主题设置到localStorage
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            
            // 添加切换动画效果
            themeToggle.style.transform = 'scale(0.9)';
            setTimeout(() => {
                themeToggle.style.transform = 'scale(1)';
            }, 150);
            
            // 更新导航栏背景色
            updateNavbarTheme(isDark);
        });
    }
}

// 更新导航栏主题
function updateNavbarTheme(isDark) {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (isDark) {
            navbar.style.background = 'rgba(26, 26, 26, 0.95)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.3)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        }
    }
}
