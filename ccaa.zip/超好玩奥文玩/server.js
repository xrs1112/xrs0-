const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 8080;

// 中间件设置
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 静态文件服务
app.use(express.static(path.join(__dirname)));

// 模拟商品数据 - 文玩手串系列
const products = [
    // 木质手串系列
    {
        id: 1,
        name: '小叶紫檀佛珠手串',
        description: '精选印度小叶紫檀，质地细腻，色泽深沉，带有淡雅檀香，佩戴舒适',
        currentPrice: 298,
        originalPrice: 398,
        image: '紫檀手串.jpg',
        category: '木质手串',
        hot: true
    },
    {
        id: 2,
        name: '海南黄花梨手串',
        description: '海南黄花梨原料，纹理清晰美观，质地坚硬，是文玩收藏的上佳之选',
        currentPrice: 1280,
        originalPrice: 1580,
        image: '黄花梨手串.jpg',
        category: '木质手串',
        hot: true
    },
    {
        id: 3,
        name: '沉香木手串',
        description: '天然沉香木制作，香味持久清雅，具有安神静心的功效，适合修身养性',
        currentPrice: 680,
        originalPrice: 880,
        image: '沉香手串.jpg',
        category: '木质手串'
    },
    {
        id: 4,
        name: '老山檀香手串',
        description: '印度老山檀香制作，香味醇厚，木质细腻，是佛教文化的经典饰品',
        currentPrice: 580,
        originalPrice: 750,
        image: '檀香手串.jpg',
        category: '木质手串'
    },
    {
        id: 5,
        name: '崖柏手串',
        description: '太行山崖柏制作，香味独特，纹理奇美，具有很高的收藏价值',
        currentPrice: 380,
        originalPrice: 480,
        image: '崖柏手串.jpg',
        category: '木质手串'
    },
    
    // 菩提手串系列
    {
        id: 6,
        name: '金刚菩提手串',
        description: '尼泊尔大金刚菩提，5瓣精品，寓意去除烦恼，带来好运和智慧',
        currentPrice: 188,
        originalPrice: 268,
        image: '金刚菩提.jpg',
        category: '菩提手串',
        new: true
    },
    {
        id: 7,
        name: '星月菩提手串',
        description: '海南星月菩提，密度高，色泽温润，是菩提中的经典品种，适合盘玩',
        currentPrice: 128,
        originalPrice: 168,
        image: '星月菩提.jpg',
        category: '菩提手串'
    },
    {
        id: 8,
        name: '凤眼菩提手串',
        description: '尼泊尔凤眼菩提，每颗都有独特的凤眼纹路，寓意智慧与觉悟',
        currentPrice: 368,
        originalPrice: 468,
        image: '凤眼菩提.jpg',
        category: '菩提手串',
        hot: true
    },
    {
        id: 9,
        name: '白玉菩提手串',
        description: '天然白玉菩提，色泽洁白如玉，质地坚硬，盘玩后会呈现温润光泽',
        currentPrice: 168,
        originalPrice: 228,
        image: '白玉菩提.jpg',
        category: '菩提手串'
    },
    
    // 水晶手串系列
    {
        id: 10,
        name: '紫水晶手串',
        description: '巴西紫水晶原料，色泽纯正，透明度高，有助于开发智慧和直觉力',
        currentPrice: 188,
        originalPrice: 248,
        image: '紫水晶手串.jpg',
        category: '水晶手串',
        new: true
    },
    {
        id: 11,
        name: '白水晶手串',
        description: '天然白水晶，晶体清澈透明，能量纯净，有净化磁场的作用',
        currentPrice: 128,
        originalPrice: 168,
        image: '白水晶手串.jpg',
        category: '水晶手串'
    },
    {
        id: 12,
        name: '粉水晶手串',
        description: '马达加斯加粉水晶，色泽柔和，被誉为爱情石，有助于增进人际关系',
        currentPrice: 158,
        originalPrice: 198,
        image: '粉水晶手串.jpg',
        category: '水晶手串'
    },
    {
        id: 13,
        name: '黑曜石手串',
        description: '天然黑曜石，具有强大的辟邪能力，能有效阻挡负能量',
        currentPrice: 88,
        originalPrice: 128,
        image: '黑曜石手串.jpg',
        category: '水晶手串'
    },
    
    // 玉石手串系列
    {
        id: 14,
        name: '和田玉手串',
        description: '新疆和田玉制作，玉质温润，触感细腻，是中华文化的瑰宝',
        currentPrice: 588,
        originalPrice: 758,
        image: '和田玉手串.jpg',
        category: '玉石手串',
        hot: true
    },
    {
        id: 15,
        name: '翡翠手串',
        description: '缅甸翡翠A货，色泽鲜艳，质地细腻，寓意平安吉祥，富贵安康',
        currentPrice: 888,
        originalPrice: 1188,
        image: '翡翠手串.jpg',
        category: '玉石手串'
    },
    {
        id: 16,
        name: '青金石手串',
        description: '阿富汗青金石，蓝色深邃，带有金色斑点，是古代皇室的专用宝石',
        currentPrice: 268,
        originalPrice: 358,
        image: '青金石手串.jpg',
        category: '玉石手串'
    },
    {
        id: 17,
        name: '南红玛瑙手串',
        description: '四川凉山南红玛瑙，色泽鲜艳如血，质地温润，具有很高的收藏价值',
        currentPrice: 388,
        originalPrice: 488,
        image: '南红手串.jpg',
        category: '玉石手串'
    },
    
    // 特色手串系列
    {
        id: 18,
        name: '蜜蜡手串',
        description: '波罗的海蜜蜡，质地温润，色泽金黄，是大自然的艺术品',
        currentPrice: 680,
        originalPrice: 880,
        image: '蜜蜡手串.jpg',
        category: '特色手串',
        new: true
    },
    {
        id: 19,
        name: '琥珀手串',
        description: '天然琥珀制作，内含史前昆虫，具有极高的科研和收藏价值',
        currentPrice: 588,
        originalPrice: 788,
        image: '琥珀手串.jpg',
        category: '特色手串'
    },
    {
        id: 20,
        name: '椰蒂手串',
        description: '海南椰蒂制作，质地坚硬，纹理独特，是热带文玩的代表作品',
        currentPrice: 158,
        originalPrice: 208,
        image: '椰蒂手串.jpg',
        category: '特色手串'
    }
];

// 模拟购物车数据
let cart = [];

// API路由

// 获取所有商品 - 支持分类筛选、分页和搜索
app.get('/api/products', (req, res) => {
    const { category, page = 1, limit = 8, search, sort } = req.query;
    let filteredProducts = [...products];
    
    // 按分类筛选
    if (category && category !== 'all') {
        filteredProducts = filteredProducts.filter(p => p.category === category);
    }
    
    // 按搜索词筛选
    if (search) {
        const searchTerm = search.toLowerCase();
        filteredProducts = filteredProducts.filter(p => 
            p.name.toLowerCase().includes(searchTerm) || 
            p.description.toLowerCase().includes(searchTerm)
        );
    }
    
    // 排序
    if (sort) {
        switch (sort) {
            case 'price_asc':
                filteredProducts.sort((a, b) => a.currentPrice - b.currentPrice);
                break;
            case 'price_desc':
                filteredProducts.sort((a, b) => b.currentPrice - a.currentPrice);
                break;
            case 'name':
                filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            default:
                // 默认排序：热门商品在前，新品在前
                filteredProducts.sort((a, b) => {
                    if (a.hot && !b.hot) return -1;
                    if (!a.hot && b.hot) return 1;
                    if (a.new && !b.new) return -1;
                    if (!a.new && b.new) return 1;
                    return 0;
                });
        }
    }
    
    // 分页
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
    
    res.json({
        success: true,
        data: paginatedProducts,
        pagination: {
            currentPage: parseInt(page),
            totalPages: Math.ceil(filteredProducts.length / limit),
            totalItems: filteredProducts.length,
            itemsPerPage: parseInt(limit),
            hasNext: endIndex < filteredProducts.length,
            hasPrev: page > 1
        }
    });
});

// 获取商品分类
app.get('/api/categories', (req, res) => {
    const categories = [...new Set(products.map(p => p.category))];
    const categoryStats = categories.map(cat => ({
        name: cat,
        count: products.filter(p => p.category === cat).length
    }));
    
    res.json({
        success: true,
        data: categoryStats
    });
});

// 获取单个商品
app.get('/api/products/:id', (req, res) => {
    const productId = parseInt(req.params.id);
    const product = products.find(p => p.id === productId);
    
    if (product) {
        res.json({
            success: true,
            data: product
        });
    } else {
        res.status(404).json({
            success: false,
            message: '商品未找到'
        });
    }
});

// 加入购物车
app.post('/api/cart/add', (req, res) => {
    const { productId, quantity = 1 } = req.body;
    const product = products.find(p => p.id === parseInt(productId));
    
    if (!product) {
        return res.status(404).json({
            success: false,
            message: '商品未找到'
        });
    }
    
    const existingItem = cart.find(item => item.productId === parseInt(productId));
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            productId: parseInt(productId),
            product: product,
            quantity: quantity
        });
    }
    
    res.json({
        success: true,
        message: '商品已加入购物车',
        cart: cart
    });
});

// 获取购物车
app.get('/api/cart', (req, res) => {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.product.currentPrice * item.quantity), 0);
    
    res.json({
        success: true,
        data: {
            items: cart,
            totalItems: totalItems,
            totalPrice: totalPrice
        }
    });
});

// 清空购物车
app.delete('/api/cart/clear', (req, res) => {
    cart = [];
    res.json({
        success: true,
        message: '购物车已清空'
    });
});

// 联系表单提交
app.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;
    
    // 简单验证
    if (!name || !email || !message) {
        return res.status(400).json({
            success: false,
            message: '请填写所有必填字段'
        });
    }
    
    // 这里可以添加邮件发送功能或保存到数据库
    console.log('收到联系表单:', { name, email, message });
    
    res.json({
        success: true,
        message: '感谢您的留言！我们会尽快回复您。'
    });
});

// 获取网站统计信息
app.get('/api/stats', (req, res) => {
    res.json({
        success: true,
        data: {
            totalProducts: products.length,
            totalCategories: [...new Set(products.map(p => p.category))].length,
            averagePrice: Math.round(products.reduce((sum, p) => sum + p.currentPrice, 0) / products.length),
            discountAverage: Math.round(products.reduce((sum, p) => sum + ((p.originalPrice - p.currentPrice) / p.originalPrice * 100), 0) / products.length)
        }
    });
});

// 处理主页路由
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// 404处理
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: '页面未找到'
    });
});

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: '服务器内部错误'
    });
});

// 启动服务器
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 服务器运行在 http://0.0.0.0:${PORT}`);
    console.log(`📱 API接口可通过 http://0.0.0.0:${PORT}/api 访问`);
    console.log(`🌐 外部访问地址: http://你的服务器IP:${PORT}`);
    console.log('✨ 商品展示网站已启动！');
}); 